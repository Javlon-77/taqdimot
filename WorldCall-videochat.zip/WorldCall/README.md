# WorldCall

Ikki kishilik real-time videochat. WebRTC media + Socket.IO signaling.

## Lokal ishga tushirish
```bash
npm install
npm start
```
So‘ng `http://localhost:3000` ni oching.

## Ikki qurilmada sinash
Bir xil Wi-Fi tarmog‘ida kompyuterning LAN IP manzilidan foydalanish mumkin. Internet orqali production hostingda HTTPS kerak.

## Deploy
Render/Railway kabi Node hostingda Start Command: `npm start`.

Eslatma: STUN serverlar mavjud. Ba’zi NAT/firewall tarmoqlarda ishonchli ulanish uchun TURN server ham qo‘shish kerak.
